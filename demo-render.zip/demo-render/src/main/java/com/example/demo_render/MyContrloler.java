package com.example.demo_render;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;

@RestController
@RequestMapping("/api")

public class MyContrloler {
    
    @RequestMapping("/hello")
    public String hello() {
        return "Hello, World!";
    }

    @RequestMapping("/greet")
    public String greet() {
        return "Greetings from the API!";
    }
}