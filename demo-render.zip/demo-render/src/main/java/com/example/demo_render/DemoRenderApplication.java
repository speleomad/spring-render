package com.example.demo_render;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoRenderApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoRenderApplication.class, args);
	}

}
