package com.example.demo_render;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoRenderApplicationTests {

	@Test
	void contextLoads() {
	}

}
